---
layout: default 
title: "About Sayid.so"
date: 07/09/2017
comments: false
categories: About Sayid.so
---
## What is Sayid.so
{{site.about}}

## Muxuu yahay sayid.so
Sayid.so waa website khaas ah, oo arima kusaabsan bulshada somaaliyeed loogu soo bandhigi. Sayid.so waxaa qorrahiisa ah nin Somaliyeed. Sayid.so waxaa lagu daaeici luuqada Somaliga iyo luuqada Ingriiska.

## Goormee la aas aasay sayid.so?
Sayid.so waxaa la aas aasay sanadkii 2015 balse waxaa aad looga shaqeeyey 2017. 

## Waamaxay sababta iyo nooca sayid.so uu udaawacanyahay?
Hadaba qaabka uu sayid.so udaawacanyahay waa qaab loogu talagalay akhris oo keliya saa darteed madooneyno in aan wax kale soo gelini. Waxaan ugu talagalnay in ruuxa soo galaa uu ufududaado in uu qoraalka akhristo.





---
layout: post
style: default
title: Welcome to sayid.so
---

Welcome to Sayid.so, first let me introduce myself you may call me Mr.Sayid.  I am the owner and sole opperator of Sayid.so. 

This personal and some what professional website will focus on two main ideas. 1. Personal Stories  2. Love and General purpose stories Sayid.so will be posted based on two languages as you may have read on the about section of this website. 



